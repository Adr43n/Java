
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class MainDePoker {
    /**
     * liste des cartes de la main. Elle sera classée par valeur et par couleur
     */
    private List<Carte> mainJoueur;

    /**
     * map triée contenant le nombre de cartes pour chaque valeur présente dans
     * la main
     */
    private Map<Valeur, Integer> nbCartesParValeur;

    /**
     * map triée contenant le nombre de cartes pour chaque couleur présente dans
     * la main
     */
    private Map<Couleur, Integer> nbCartesParCouleur;

    /**
     * crée une main de poker à partir d'un tableau de cartes
     * 
     * @param cartes
     * @throws l'exception TricheurException si le nombre de carte est différent
     *                     de 5
     * @throws l'exception TricheurException s'il existe des cartes identiques
     */
    public MainDePoker(Carte[] cartes) throws TricheurException {
        // à compléter
    }

    @Override
    public String toString() {
        return "mainJoueur=" + this.mainJoueur + "\nnbCartesParValeur="
                + this.nbCartesParValeur + "\nnbCartesParCouleur="
                + this.nbCartesParCouleur;
    }

    public Iterator<Carte> iterateurDeCarte() {
        // à compléter
    }

    private Carte plusGrandeCarte() {
        return this.mainJoueur.get(0);
    }

    private Valeur plusGrandeValeur() {
        return this.mainJoueur.get(0).getValeur();
    }

    /**
     * examine si la main correspond à une suite de valeurs consécutives
     * indépendemment de la couleur
     */
    private boolean estUneSuiteDeValeurs() {
        int rangPremièreValeur = this.plusGrandeValeur().ordinal();
        for (int i = 1; i < 5; i++) {
            if (this.mainJoueur.get(i).getValeur()
                    .ordinal() != rangPremièreValeur + i) {
                return false;
            }
        }
        return true;
    }

    public boolean isQuinteFlushRoyale() {
        // à compléter
        return false;
    }

    public boolean isQuinteFlush() {
        // à compléter
        return false;
    }

    public boolean isCarré() {
        // à compléter
        return false;
    }

    public boolean isFull() {
        // à compléter
        return false;
    }

    public boolean isCouleur() {
        // à compléter
        return false;
    }

    public boolean isSuite() {
        // à compléter
        return false;
    }

    public boolean isBrelan() {
        // à compléter
        return false;
    }

    public boolean isDoublePaire() {
        // à compléter
        return false;
    }

    public boolean isPaire() {
        // à compléter
        return false;
    }

    public boolean isHauteur() {
        // à compléter
        return false;
    }

    public String annonce() {
        // à compléter
        return null;
    }
}
